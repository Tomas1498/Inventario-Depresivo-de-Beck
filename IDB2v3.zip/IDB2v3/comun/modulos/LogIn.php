<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Conectar a la Base de Datos
    require '../Bd/ConexionBD.php';

    //variables de busqueda
    $mensaje = '';
    $Co = $_POST['correoElectronico'];
    $psw = $_POST['contraseña'];

    // Preparar la consulta para evitar inyecciones SQL
    $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE Email = ? AND Contrasena = ?");
    $stmt->bind_param('ss', $Co, $psw); // Vincula las variables a los parámetros de la consulta
    $stmt->execute(); // Ejecuta la consulta preparada
    $resultado = $stmt->get_result(); // Obtiene el conjunto de resultados de la consulta

    // Verificar si la consulta se ejecutó correctamente
    if ($resultado !== false) {
        // Si el usuario existe, inicia sesión
        if ($resultado->num_rows > 0) {
            session_start();
            $usuario = $resultado->fetch_assoc(); // Obtiene la fila de resultados como un array asociativo
            // Almacena el email y el rol del usuario en una sesión
            $_SESSION['usuario_id'] = $usuario['ID']; // Asegúrate de que la columna de id sea 'ID'
            $_SESSION['email'] = $usuario['Email'];
            $_SESSION['rol'] = $usuario['rol'];
            // Redirige al usuario a la página principal
            header("Location: ../../Inicio.php");
            exit; // ¡Importante! Asegúra de salir del script después de la redirección
        } else {
            // Muestra un mensaje de error
            $mensaje = "El usuario o la contraseña no son correctos.";
        }
    } else {
        // Si hubo un error en la ejecución de la consulta, muestra un mensaje de error
        $mensaje = "Error en la consulta: " . mysqli_error($conexion);
    }
}
