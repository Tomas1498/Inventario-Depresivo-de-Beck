<?php
// Verificar si se ha proporcionado el ID del usuario
if (!isset($_GET['id_usuario'])) {
    echo "ID de usuario no proporcionado.";
    exit();
}

$id_usuario = intval($_GET['id_usuario']); // Asegurarse de que es un número entero

// Conectar a la base de datos
require '../Bd/ConexionBD.php';

// Consulta SQL para obtener el nombre del usuario
$sql_usuario = "SELECT Nombre FROM usuarios WHERE ID = ?";
$stmt_usuario = $conexion->prepare($sql_usuario);
$stmt_usuario->bind_param('i', $id_usuario);
$stmt_usuario->execute();
$resultado_usuario = $stmt_usuario->get_result();

// Verificar si se encontró el usuario
if ($resultado_usuario && $resultado_usuario->num_rows > 0) {
    $fila_usuario = $resultado_usuario->fetch_assoc();
    $nombre_usuario = htmlspecialchars($fila_usuario['Nombre']);
    echo "<p class='Info_center'><b>$nombre_usuario</b>.<br>
   
    Si quiere verificar el resultado abra este enlace para ver la tabla de puntajes. <b><a href=../img/Tabla_puntaje.png target=_blank>Tabla de puntaje inventario Beck </a></b>
    <br>
    Se recomienda que cambie el nombre del archivo pdf al descargarlo para mayor control personal.
    <b><a href=../PHP/ResultadosAdmin.php>Presione aquí para regresar</a></b></p>";
} else {
    echo "<p class='Info_center'>Usuario no encontrado</p>";
    $stmt_usuario->close();
    $conexion->close();
    exit();
}

$stmt_usuario->close();

// Consulta SQL para obtener los resultados del usuario
$sql_resultados = "SELECT * FROM Estado_MentalUsuarios WHERE Id_Usuario = ?";
$stmt_resultados = $conexion->prepare($sql_resultados);
$stmt_resultados->bind_param('i', $id_usuario);
$stmt_resultados->execute();
$resultado_resultados = $stmt_resultados->get_result();

// Comprobar si hay resultados
if ($resultado_resultados && $resultado_resultados->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>PDF formulario</th>";
    echo "<th>Estado Mental</th>";
    echo "<th>Puntaje</th>";
    echo "<th>Fecha del Formulario</th>";
    echo "</tr>";
// Leer el contenido del archivo SVG
$svg_icon = file_get_contents('../img/pdf-svgrepo-com.svg'); 
// Añadir atributos de tamaño al SVG (opcional, si el SVG no tiene atributos width y height)
$svg_icon = str_replace('<svg ', '<svg width="40" height="40" ', $svg_icon);
    // Iterar sobre los resultados y mostrar cada registro en una fila de la tabla
    while ($fila_resultados = $resultado_resultados->fetch_assoc()) {
        echo "<tr>";
        echo "<td><a href='" . htmlspecialchars($fila_resultados['Ruta_PDF']) . "' target='_blank' >" . $svg_icon . "</a></td>";
        echo "<td>" . htmlspecialchars($fila_resultados['Estado_Mental']) . "</td>";
        echo"<td>" . htmlspecialchars($fila_resultados['Puntaje']) . "</td>";
        echo "<td>" . htmlspecialchars($fila_resultados['Fecha_Formulario']) . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No se encontraron resultados para este usuario.";
}

// Liberar el resultado y cerrar la conexión
$resultado_resultados->free();
$stmt_resultados->close();
$conexion->close();
?>
