<?php
// Conectar a la Base de Datos
require '../Bd/ConexionBD.php';

// Consulta SQL para obtener la información de los usuarios
$sql = "SELECT * FROM usuarios";

// Ejecutar la consulta
$resultado = mysqli_query($conexion, $sql);

// Comprobar si hay resultados
if ($resultado && mysqli_num_rows($resultado) > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Usuarios</th>";
    echo "<th>No.Control</th>";
    echo "<th>Carrera</th>";
    echo "<th>Resultados</th>";
    
    echo "</tr>";

    // Iterar sobre los resultados y mostrar cada usuario en una fila de la tabla
    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($fila['Nombre']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['No_Control']) . "</td>";
        echo "<td>" . htmlspecialchars($fila['Carrera']) . "</td>";
        echo "<td><a href='../PHP/ResultadosX_Usuario.php?id_usuario=" . urlencode($fila['ID']) . "'>resultados</a></td>";
      
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No se encontraron usuarios.";
}

// Liberar el resultado y cerrar la conexión
mysqli_free_result($resultado);
mysqli_close($conexion);
?>
