<?php
session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

$usuario_id = $_SESSION['usuario_id'];

// Conectar a la base de datos
require '../Bd/ConexionBD.php';

// Obtener el nombre del usuario desde la base de datos
$stmt_usuario = $conexion->prepare("SELECT nombre FROM usuarios WHERE id = ?");
$stmt_usuario->bind_param('i', $usuario_id);
$stmt_usuario->execute();
$stmt_usuario->bind_result($nombre_usuario);
$stmt_usuario->fetch();
$stmt_usuario->close();

// Obtener las respuestas del formulario
$respuestas = [];
$error = false;

for ($i = 1; $i <= 21; $i++) {
    $key = "respuesta" . $i;
    if (isset($_POST[$key])) {
        list($valor, $texto) = explode('|', $_POST[$key]);
        $respuestas[$key] = [
            'valor' => (int)$valor,
            'texto' => $texto
        ];
    }
}



// Calcular la suma de los valores de las respuestas
$suma_puntajes = array_sum(array_column($respuestas, 'valor'));

// Determinar el estado mental del usuario según el puntaje obtenido
if ($suma_puntajes >= 0 && $suma_puntajes <= 13) {
    $estado_mental = "Depresión/Ansiedad nula";
} elseif ($suma_puntajes >= 14 && $suma_puntajes <= 19) {
    $estado_mental = "Depresión/Ansiedad minima";
} elseif ($suma_puntajes >= 20 && $suma_puntajes <= 28) {
    $estado_mental = "Depresión/Ansiedad Moderada";
} elseif ($suma_puntajes >= 29 && $suma_puntajes <= 63) {
    $estado_mental = "Depresión/Ansiedad Grave";
} else {
    $estado_mental = "Estado no determinado";
}

// Calcular la fecha actual
$fecha_actual = date("Y-m-d");

// Incluir FPDF
require('../fpdf/fpdf.php');

// Crear el PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 12);

// Agregar nombre del usuario y fecha al inicio del PDF
$pdf->Cell(0, 10, "Nombre del usuario: $nombre_usuario", 0, 1);
$pdf->Cell(0, 10, "Fecha: $fecha_actual", 0, 1);
$pdf->Ln(10); // Añadir un espacio en blanco

// Mapear preguntas
$preguntas = [
    "1. Tristeza", "2. Pesimismo", "3. Fracaso", "4. Perdida de placer", "5. Sentimientos de culpa",
    "6. Sentimientos de castigo", "7. Disconformidad con uno mismo", "8. Autocritica", "9. Pensamientos o deseos suicidas",
    "10. Llanto", "11. Agitacion", "12. Perdida de interes", "13. Indecision", "14. Desvalorizacion", "15. Perdida de energia",
    "16. Cambios en los habitos de sueno", "17. Irritabilidad", "18. Cambios en el apetito", "19. Dificultad de concentracion",
    "20. Cansancio o fatiga", "21. Perdida de interes en el sexo"
];

foreach ($preguntas as $index => $pregunta) {
    $respuesta = $respuestas["respuesta" . ($index + 1)]['texto'];
    $pdf->MultiCell(0, 10, "$pregunta: $respuesta", 0, 'L');
}

// Generar un nombre único para el PDF
$pdf_filename = uniqid("respuestas_usuario_$nombre_usuario_") . ".pdf";
$pdf_path = "../Includes/pdfs/$pdf_filename";

// Guardar el PDF en un archivo
$pdf->Output('F', $pdf_path);

// Preparar la consulta SQL para insertar los datos en la tabla Estado_MentalUsuarios
$stmt_resultados = $conexion->prepare("
    INSERT INTO estado_mentalusuarios (Id_usuario, Estado_Mental, Fecha_Formulario, Ruta_PDF, Puntaje)
    VALUES (?, ?, ?, ?,?)
");

// Vincular los parámetros para la tabla de resultados
$stmt_resultados->bind_param('isssi', $usuario_id, $estado_mental, $fecha_actual, $pdf_path, $suma_puntajes);

// Ejecutar la consulta para insertar los datos en la tabla de resultados
$stmt_resultados->execute();

// Cerrar las declaraciones
$stmt_resultados->close();

// Redirigir a la página de inicio con un mensaje de éxito
header('Location: ../../Inicio.php?mensaje=exito');
exit();
?>
