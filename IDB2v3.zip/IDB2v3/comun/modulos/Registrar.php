<?php # Script 4.11

// Verificar que se envió el formulario
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$mensaje='';
	//$mensaje .= '<p class="hizo">Registro enviado</p>';
	// Conectar a la Base de Datos
	require '../Bd/ConexionBD.php';
	// Preparar la consulta para registrar los datos en la tabla 'users'
	$Nm= $_POST['registrousuario'];
	$No_C= $_POST['númeroControl'];
	$Ca= $_POST['carreras'];
	$Em=$_POST['correoElectronico'];
	$Psw=$_POST['contraseña'];
	$Rol=$_POST['rol'];
	$query = "INSERT INTO usuarios (Nombre,No_Control,Carrera,Email,Contrasena, rol)
				VALUES ('$Nm', '$No_C', '$Ca', '$Em','$Psw','$Rol')";
	// ejecutar la consulta
	$resultado = @mysqli_query($conexion,$query);
	//Si la consulta tuvo éxito, entonces imprimir un mensaje
	if ($resultado) {
		$mensaje.='<p class="hacer">Registro exitoso</p>';;
	}
	//Pero si no tuvo éxito mandar el mensaje correspondiente
	// Debugging message:
	else{
		$mensaje.='<p class="error">No se pudo registar </br>';
		$mensaje.='Motivo: '. mysqli_error($conexion).'</p>';
	}

	// Cerrar la conexión a la base de datos
	mysqli_close($conexion);
	
}

?>