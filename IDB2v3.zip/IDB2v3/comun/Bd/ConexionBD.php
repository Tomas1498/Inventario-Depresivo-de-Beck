<?php # Script 9.2 - mysqli_connect.php

//  
// Este archivo establece la conección a MySQL
// 

// Define constantes para acceso a la Base de Datos:
DEFINE ('DB_NAME', 'inventario_berck');
DEFINE ('DB_USER', 'root');
DEFINE ('DB_PASS', '');
DEFINE ('DB_HOST', 'localhost');

// Realizar la conexión:
$conexion = @mysqli_connect (DB_HOST, DB_USER, DB_PASS, DB_NAME) 
			OR die ('No se puede conectar a MySQL: ' . mysqli_connect_error() );

// Codificación de caracteres...
mysqli_set_charset($conexion, 'utf8');