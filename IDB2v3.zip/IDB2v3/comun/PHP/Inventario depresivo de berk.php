<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Invetario de berk 2</title>
    <script src="../JS/Asegurar_E.pregunta.js"></script>
</head>

<body>
    <header>
        <div class="header-container">
            <div style="width: 100%;display: flex;flex-direction: row;flex-wrap: nowrap;justify-content: space-between;align-items: center;">
                <img class="img-logo" src="https://cdmadero.tecnm.mx/images/logo-itcm-v2.png" alt="ITCM">
                <!--Texto blacno y fw-bold float-end-->

                <nav class="sticker">
                    <ul class="menu">
                        <li><a class="header-container__a" href="../../Inicio.php">Inicio</a>
                        </li>

                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <main>
        <div class="division">

            <div class="division__form">
                <h1 class="division__h1">Inventario depresivo de Beck II</h1>
                <p class=" Info_center">El Inventario Depresivo de Beck (BDI) es una herramienta psicométrica diseñada
                    para medir la gravedad de los síntomas depresivos y ansiosos en individuos adolescentes y adultos.
                    Este cuestionario consta de 21 grupos de afirmaciones. Cada respuesta cuenta con 4 respuestas con un
                    valor de 0 a 3 de puntaje en ese orden. Por favor, lea con atención cada uno de ellos cuidadosamente.
                    Luego elija uno de cada grupo, el que mejor describa el modo como se ha sentido las últimas dos semanas,
                    incluyendo el día de hoy.Marque con un círculo el número correspondiente al enunciado elegido Si varios
                    enunciados de un mismo grupo le parecen igualmente apropiados, marque el número más alto
                    (recordando que el valor de las respuestas es de 0 a 3).</p>


                <div class="formulario">
             
                    <form method="post" action="../modulos/ProcesarRespuestas.php" enctype="multipart/form-data" onsubmit="return validarFormulario();">
                        <fieldset>
                            <legend ><b>1. Tristeza</b></legend>
                            <p><input type="radio" id="respuestas1-0" name="respuesta1" value="0|No me siento triste.">
                                <label for="respuestas1-0">No me siento triste.</label>
                            </p>
                            <p><input type="radio" id="respuestas1-1" name="respuesta1" value="1|Me siento triste gran parte del tiempo.">
                                <label for="respuestas1-1">Me siento triste gran parte del tiempo.</label>
                            </p>
                            <p><input type="radio" id="respuestas1-2" name="respuesta1" value="2|Me siento triste todo el tiempo.">
                                <label for="respuestas1-2">Me siento triste todo el tiempo.</label>
                            </p>
                            <p><input type="radio" id="respuestas1-3" name="respuesta1" value="3|Me siento tan triste o soy tan infeliz que no puedo soportarlo.">
                                <label for="respuestas1-3">Me siento tan triste o soy tan infeliz que no puedo soportarlo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>2. Pesimismo</b></legend>
                            <p><input type="radio" id="respuestas2-0" name="respuesta2" value="0|No estoy desalentado respecto del mi futuro.">
                                <label for="respuestas2-0">No estoy desalentado respecto del mi futuro.</label>
                            </p>
                            <p><input type="radio" id="respuestas2-1" name="respuesta2" value="1|Me siento mas desalentado respecto de mi futuro que lo que solia estarlo.">
                                <label for="respuestas2-1">Me siento más desalentado respecto de mi futuro que lo que solía estarlo.</label>
                            </p>
                            <p><input type="radio" id="respuestas2-2" name="respuesta2" value="2|No espero que las cosas funcionen para mi.">
                                <label for="respuestas2-2">No espero que las cosas funcionen para mi.</label>
                            </p>
                            <p><input type="radio" id="respuestas2-3" name="respuesta2" value="3|Siento que no hay esperanza para mi futuro y que solo puede empeorar.">
                                <label for="respuestas2-3">Siento que no hay esperanza para mi futuro y que sólo puede empeorar.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>3. Fracaso</b></legend>
                            <p><input type="radio" id="respuestas3-0" name="respuesta3" value="0|No me siento como un fracasado.">
                                <label for="respuestas3-0">No me siento como un fracasado.</label>
                            </p>
                            <p><input type="radio" id="respuestas3-1" name="respuesta3" value="1|He fracasado mas de lo que hubiera debido.">
                                <label for="respuestas3-1">He fracasado más de lo que hubiera debido.</label>
                            </p>
                            <p><input type="radio" id="respuestas3-2" name="respuesta3" value="2|Cuando miro hacia atras, veo muchos fracasos.">
                                <label for="respuestas3-2">Cuando miro hacia atrás, veo muchos fracasos.</label>
                            </p>
                            <p><input type="radio" id="respuestas3-3" name="respuesta3" value="3|Siento que como persona soy un fracaso total.">
                                <label for="respuestas3-3">Siento que como persona soy un fracaso total.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>4. Pérdida de placer</b></legend>
                            <p><input type="radio" id="respuestas4-0" name="respuesta4" value="0|Obtengo tanto placer como siempre por las cosas de las que disfruto.">
                                <label for="respuestas4-0">Obtengo tanto placer como siempre por las cosas de las que disfruto.</label>
                            </p>
                            <p><input type="radio" id="respuestas4-1" name="respuesta4" value="1|No disfruto tanto de las cosas como solia hacerlo.">
                                <label for="respuestas4-1">No disfruto tanto de las cosas como solía hacerlo.</label>
                            </p>
                            <p><input type="radio" id="respuestas4-2" name="respuesta4" value="2|Obtengo muy poco placer de las cosas que solia disfrutar.">
                                <label for="respuestas4-2">Obtengo muy poco placer de las cosas que solía disfrutar.</label>
                            </p>
                            <p><input type="radio" id="respuestas4-3" name="respuesta4" value="3|No puedo obtener ningun placer de las cosas de las que solia disfrutar.">
                                <label for="respuestas4-3">No puedo obtener ningún placer de las cosas de las que solía disfrutar.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>5. Sentimientos de culpa</b></legend>
                            <p><input type="radio" id="respuestas5-0" name="respuesta5" value="0|No me siento particularmente culpable.">
                                <label for="respuestas5-0">No me siento particularmente culpable.</label>
                            </p>
                            <p><input type="radio" id="respuestas5-1" name="respuesta5" value="1|Me siento culpable respecto de varias cosas que he hecho o que deberia haber hecho.">
                                <label for="respuestas5-1">Me siento culpable respecto de varias cosas que he hecho o que debería haber hecho.</label>
                            </p>
                            <p><input type="radio" id="respuestas5-2" name="respuesta5" value="2|Me siento bastante culpable la mayor parte del tiempo.">
                                <label for="respuestas5-2">Me siento bastante culpable la mayor parte del tiempo.</label>
                            </p>
                            <p><input type="radio" id="respuestas5-3" name="respuesta5" value="3|Me siento culpable todo el tiempo.">
                                <label for="respuestas5-3">Me siento culpable todo el tiempo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>6. Sentimientos de castigo</b></legend>
                            <p><input type="radio" id="respuestas6-0" name="respuesta6" value="0|No siento que este siendo castigado.">
                                <label for="respuestas6-0">No siento que este siendo castigado.</label>
                            </p>
                            <p><input type="radio" id="respuestas6-1" name="respuesta6" value="1|Siento que tal vez pueda ser castigado.">
                                <label for="respuestas6-1">Siento que tal vez pueda ser castigado.</label>
                            </p>
                            <p><input type="radio" id="respuestas6-2" name="respuesta6" value="2|Espero ser castigado.">
                                <label for="respuestas6-2">Espero ser castigado.</label>
                            </p>
                            <p><input type="radio" id="respuestas6-3" name="respuesta6" value="3|Siento que estoy siendo castigado.">
                                <label for="respuestas6-3">Siento que estoy siendo castigado.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>7. Disconformidad con uno mismo</b></legend>
                            <p><input type="radio" id="respuestas7-0" name="respuesta7" value="0|Siento acerca de mi lo mismo que siempre.">
                                <label for="respuestas7-0">Siento acerca de mi lo mismo que siempre.</label>
                            </p>
                            <p><input type="radio" id="respuestas7-1" name="respuesta7" value="1|He perdido la confianza en mi mismo.">
                                <label for="respuestas7-1">He perdido la confianza en mí mismo.</label>
                            </p>
                            <p><input type="radio" id="respuestas7-2" name="respuesta7" value="2|Estoy decepcionado conmigo mismo.">
                                <label for="respuestas7-2">Estoy decepcionado conmigo mismo.</label>
                            </p>
                            <p><input type="radio" id="respuestas7-3" name="respuesta7" value="3|No me gusto a mi mismo.">
                                <label for="respuestas7-3">No me gusto a mí mismo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>8. Autocrítica</b></legend>
                            <p><input type="radio" id="respuestas8-0" name="respuesta8" value="0|No me critico ni me culpo mas de lo habitual.">
                                <label for="respuestas8-0">No me critico ni me culpo más de lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas8-1" name="respuesta8" value="1|Estoy mas critico conmigo mismo de lo que solia estarlo.">
                                <label for="respuestas8-1">Estoy más crítico conmigo mismo de lo que solía estarlo.</label>
                            </p>
                            <p><input type="radio" id="respuestas8-2" name="respuesta8" value="2|Me critico a mi mismo por todos mis errores.">
                                <label for="respuestas8-2">Me critico a mí mismo por todos mis errores.</label>
                            </p>
                            <p><input type="radio" id="respuestas8-3" name="respuesta8" value="3|Me culpo a mi mismo por todo lo malo que sucede.">
                                <label for="respuestas8-3">Me culpo a mí mismo por todo lo malo que sucede.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>9. Pensamientos o deseos suicidas</b></legend>

                            <p><input type="radio" id="respuestas9-0" name="respuesta9" value="0|No tengo ningun pensamiento de suicidio.">
                                <label for="respuestas9-0">No tengo ningún pensamiento de suicidio.</label>
                            </p>
                            <p><input type="radio" id="respuestas9-1" name="respuesta9" value="1|He tenido pensamientos de suicidio, pero no los llevaria a cabo.">
                                <label for="respuestas9-1">He tenido pensamientos de suicidio, pero no los llevaría a cabo.</label>
                            </p>
                            <p><input type="radio" id="respuestas9-2" name="respuesta9" value="2|Querria suicidarme.">
                                <label for="respuestas9-2">Querría suicidarme.</label>
                            </p>
                            <p><input type="radio" id="respuestas9-3" name="respuesta9" value="3|Me suicidaria si tuviera la oportunidad.">
                                <label for="respuestas9-3">Me suicidaría si tuviera la oportunidad.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>10. Llanto</b></legend>
                            <p><input type="radio" id="respuestas10-0" name="respuesta10" value="0|No lloro mas de lo que solia llorar.">
                                <label for="respuestas10-0">No lloro mas de lo que solia llorar.</label>
                            </p>
                            <p><input type="radio" id="respuestas10-1" name="respuesta10" value="1|Lloro mas de lo que solia llorar.">
                                <label for="respuestas10-1">Lloro mas de lo que solia llorar.</label>
                            </p>
                            <p><input type="radio" id="respuestas10-2" name="respuesta10" value="2|Lloro por cualquier pequenez.">
                                <label for="respuestas10-2">Lloro por cualquier pequenez.</label>
                            </p>
                            <p><input type="radio" id="respuestas10-3" name="respuesta10" value="3|Siento ganas de llorar, pero no puedo.">
                                <label for="respuestas10-3">Siento ganas de llorar, pero no puedo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>11. Agitación</b></legend>
                            <p><input type="radio" id="respuestas11-0" name="respuesta11" value="0|No estoy mas inquieto o tenso que lo habitual.">
                                <label for="respuestas11-0">No estoy más inquieto o tenso que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas11-1" name="respuesta11" value="1|Me siento mas inquieto o tenso que lo habitual.">
                                <label for="respuestas11-1">Me siento más inquieto o tenso que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas11-2" name="respuesta11" value="2|Estoy tan inquieto o agitado que me es dificil quedarme quieto.">
                                <label for="respuestas11-2">Estoy tan inquieto o agitado que me es difícil quedarme quieto.</label>
                            </p>
                            <p><input type="radio" id="respuestas11-3" name="respuesta11" value="3|Estoy tan inquieto o agitado que tengo que estar siempre en movimiento o haciendo algo.">
                                <label for="respuestas11-3">Estoy tan inquieto o agitado que tengo que estar siempre en movimiento o haciendo algo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>12. Pérdida de interés</b></legend>
                            <p><input type="radio" id="respuestas12-0" name="respuesta12" value="0|No he perdido el interes en otras actividades o personas.">
                                <label for="respuestas12-0">No he perdido el interés en otras actividades o personas.</label>
                            </p>
                            <p><input type="radio" id="respuestas12-1" name="respuesta12" value="1|Estoy menos interesado en otras actividades o personas de lo que solia estarlo.">
                                <label for="respuestas12-1">Estoy menos interesado en otras actividades o personas de lo que solía estarlo.</label>
                            </p>
                            <p><input type="radio" id="respuestas12-2" name="respuesta12" value="2|He perdido casi todo el interes en otras actividades o personas.">
                                <label for="respuestas12-2">He perdido casi todo el interés en otras actividades o personas.</label>
                            </p>
                            <p><input type="radio" id="respuestas12-3" name="respuesta12" value="3|Me es dificil interesarme por cualquier cosa.">
                                <label for="respuestas12-3">Me es difícil interesarme por cualquier cosa.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>13. Indecisión</b></legend>
                            <p><input type="radio" id="respuestas13-0" name="respuesta13" value="0|Tomo decisiones tan bien como siempre.">
                                <label for="respuestas13-0">Tomo decisiones tan bien como siempre.</label>
                            </p>
                            <p><input type="radio" id="respuestas13-1" name="respuesta13" value="1|Me es mas dificil tomar decisiones que de costumbre.">
                                <label for="respuestas13-1">Me es más difícil tomar decisiones que de costumbre.</label>
                            </p>
                            <p><input type="radio" id="respuestas13-2" name="respuesta13" value="2|Encuentro mucha mas dificultad para tomar decisiones que antes.">
                                <label for="respuestas13-2">Encuentro mucha más dificultad para tomar decisiones que antes.</label>
                            </p>
                            <p><input type="radio" id="respuestas13-3" name="respuesta13" value="3|Tengo problemas para tomar cualquier decision.">
                                <label for="respuestas13-3">Tengo problemas para tomar cualquier decisión.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>14. Desvalorización</b></legend>
                            <p><input type="radio" id="respuestas14-0" name="respuesta14" value="0|No siento que yo no sea valioso.">
                                <label for="respuestas14-0">No siento que yo no sea valioso.</label>
                            </p>
                            <p><input type="radio" id="respuestas14-1" name="respuesta14" value="1|No me considero tan valioso y util como solia considerarme.">
                                <label for="respuestas14-1">No me considero tan valioso y útil como solía considerarme.</label>
                            </p>
                            <p><input type="radio" id="respuestas14-2" name="respuesta14" value="2|Me siento menos valioso cuando me comparo con otros.">
                                <label for="respuestas14-2">Me siento menos valioso cuando me comparo con otros.</label>
                            </p>
                            <p><input type="radio" id="respuestas14-3" name="respuesta14" value="3|Siento que no valgo nada.">
                                <label for="respuestas14-3">Siento que no valgo nada.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>15. Pérdida de energía</b></legend>
                            <p><input type="radio" id="respuestas15-0" name="respuesta15" value="0|Tengo tanta energia como siempre.">
                                <label for="respuestas15-0">Tengo tanta energía como siempre.</label>
                            </p>
                            <p><input type="radio" id="respuestas15-1" name="respuesta15" value="1|Tengo menos energia que la que solia tener.">
                                <label for="respuestas15-1">Tengo menos energía que la que solía tener.</label>
                            </p>
                            <p><input type="radio" id="respuestas15-2" name="respuesta15" value="2|No tengo suficiente energia para hacer demasiadas cosas.">
                                <label for="respuestas15-2">No tengo suficiente energía para hacer demasiadas cosas.</label>
                            </p>
                            <p><input type="radio" id="respuestas15-3" name="respuesta15" value="3|Me es dificil hacer cualquier cosa.">
                                <label for="respuestas15-3">Me es difícil hacer cualquier cosa.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>16. Cambios en los hábitos de sueño</b></legend>
                        
                            <p><input type="radio" id="respuestas16-0" name="respuesta16" value="0|No he experimentado ningun cambio en mis habitos de sueno.">
                                <label for="respuestas16-0">No he experimentado ningún cambio en mis hábitos de sueño.</label>
                            </p>
                            <p><input type="radio" id="respuestas16-1" name="respuesta16" value="1|Duermo un poco mas de lo habitual/Duermo un poco menos de lo habitual.">
                                <label for="respuestas16-1">Duermo un poco más de lo habitual/Duermo un poco menos de lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas16-3" name="respuesta16" value="2|Duermo mucho mas de lo habitual/Duermo mucho menos de lo habitual.">
                                <label for="respuestas16-3">Duermo mucho más de lo habitual/Duermo mucho menos de lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas16-5" name="respuesta16" value="3|Duermo la mayor parte del dia/Me despierto 1-2 horas mas temprano y no puedo volver a dormirme.">
                                <label for="respuestas16-5">Duermo la mayor parte del día/
                                    Me despierto 1-2 horas más temprano y no puedo volver a dormirme.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>17. Irritabilidad</b></legend>
                            <p><input type="radio" id="respuestas17-0" name="respuesta17" value="0|No estoy tan irritable que de costumbre.">
                                <label for="respuestas17-0">No estoy tan irritable que de costumbre.</label>
                            </p>
                            <p><input type="radio" id="respuestas17-1" name="respuesta17" value="1|Estoy mas irritable que lo habitual.">
                                <label for="respuestas17-1">Estoy más irritable que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas17-2" name="respuesta17" value="2|Estoy mucho mas irritable que lo habitual.">
                                <label for="respuestas17-2">Estoy mucho más irritable que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas17-3" name="respuesta17" value="3|Estoy irritable todo el tiempo.">
                                <label for="respuestas17-3">Estoy irritable todo el tiempo.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>18. Cambios en el apetito</b></legend>
                            <p><input type="radio" id="respuestas18-0" name="respuesta18" value="0|No he experimentado ningun cambio en mi apetito.">
                                <label for="respuestas18-0">No he experimentado ningún cambio en mi apetito.</label>
                            </p>
                            <p><input type="radio" id="respuestas18-1" name="respuesta18" value="1|Mi apetito es un poco menor que lo habitual
                                    /Mi apetito es un poco mayor que lo habitual.">
                                <label for="respuestas18-1">Mi apetito es un poco menor que lo habitual/Mi apetito es un poco mayor que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas18-3" name="respuesta18" value="2|Mi apetito es mucho menor que antes/Mi apetito es mucho mayor que antes.">
                                <label for="respuestas18-3">Mi apetito es mucho menor que antes/Mi apetito es mucho mayor que antes.</label>
                            </p>
                            <p><input type="radio" id="respuestas18-5" name="respuesta18" value="3|No tengo apetito en absoluto/Quiero comer todo el día.">
                                <label for="respuestas18-5">No tengo apetito en absoluto/Quiero comer todo el día.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>19. Dificultad de concentración</b></legend>
                            <p><input type="radio" id="respuestas19-0" name="respuesta19" value="0|Puedo concentrarme tan bien como siempre.">
                                <label for="respuestas19-0">Puedo concentrarme tan bien como siempre.</label>
                            </p>
                            <p><input type="radio" id="respuestas19-1" name="respuesta19" value="1|No puedo concentrarme tan bien como habitualmente.">
                                <label for="respuestas19-1">No puedo concentrarme tan bien como habitualmente.</label>
                            </p>
                            <p><input type="radio" id="respuestas19-2" name="respuesta19" value="2|Me es dificil mantener la mente en algo por mucho tiempo.">
                                <label for="respuestas19-2">Me es difícil mantener la mente en algo por mucho tiempo.</label>
                            </p>
                            <p><input type="radio" id="respuestas19-3" name="respuesta19" value="3|Encuentro que no puedo concentrarme en nada.">
                                <label for="respuestas19-3">Encuentro que no puedo concentrarme en nada.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend><b>20. Cansancio o fatiga</b></legend>
                            <p><input type="radio" id="respuestas20-0" name="respuesta20" value="0|No estoy mas cansado o fatigado que lo habitual.">
                                <label for="respuestas20-0">No estoy más cansado o fatigado que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas20-1" name="respuesta20" value="1|Me fatigo o me canso mas facilmente que lo habitual.">
                                <label for="respuestas20-1">Me fatigo o me canso más fácilmente que lo habitual.</label>
                            </p>
                            <p><input type="radio" id="respuestas20-2" name="respuesta20" value="2|Estoy demasiado fatigado o cansado para hacer muchas de las cosas que solia hacer.">
                                <label for="respuestas20-2">Estoy demasiado fatigado o cansado para hacer muchas de las cosas que solía hacer.</label>
                            </p>
                            <p><input type="radio" id="respuestas20-3" name="respuesta20" value="3|Estoy demasiado fatigado o cansado para hacer la mayoria de las cosas que solia hacer.">
                                <label for="respuestas20-3">Estoy demasiado fatigado o cansado para hacer la mayoría de las cosas que solía hacer.</label>
                            </p>
                        </fieldset>

                        <fieldset>
                            <legend name="respuesta21"><b>21. Pérdida de interés en el sexo</b></legend>
                            <p><input type="radio" id="respuestas21-0" name="respuesta21" value="0|No he notado ningun cambio reciente en mi interes por el sexo.">
                                <label for="respuestas21-0">No he notado ningún cambio reciente en mi interés por el sexo.</label>
                            </p>
                            <p><input type="radio" id="respuestas21-1" name="respuesta21" value="1|Estoy menos interesado en el sexo de lo que solia estarlo.">
                                <label for="respuestas21-1">Estoy menos interesado en el sexo de lo que solía estarlo.</label>
                            </p>
                            <p><input type="radio" id="respuestas21-2" name="respuesta21" value="2|Estoy mucho menos interesado en el sexo ahora.">
                                <label for="respuestas21-2">Estoy mucho menos interesado en el sexo ahora.</label>
                            </p>
                            <p><input type="radio" id="respuestas21-3" name="respuesta21" value="3|He perdido completamente el interes en el sexo.">
                                <label for="respuestas21-3">He perdido completamente el interés en el sexo.</label>
                            </p>
                        </fieldset>
                        <div id="mensajeError" style="color: red;"></div>
                        <p><input class="division__button" type="submit" value="Enviar"></p>
                    </form>
                </div>
            </div>
        </div>
        </div>

        </div>
        </div>
    </main>
    <footer class="pie-pagina text-center" id="myFooter">
        <p>Powered By ISC ITCM © 2024.</p>
    </footer>

    <script src="../JS/controlFooter.js"></script>

</body>

</html>