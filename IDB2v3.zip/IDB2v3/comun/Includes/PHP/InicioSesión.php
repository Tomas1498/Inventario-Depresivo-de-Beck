<?php
$mensaje='';
include ('../modulos/LogIn.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/Registro.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css.map">
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">


    <title>Iniciar Sesión</title>
    <style type="text/css" id="operaUserStyle"></style>
</head>

<body>
    <header>
        <div class="header-container">
            <div
                style="width: 100%;display: flex;flex-direction: row;flex-wrap: nowrap;justify-content: space-between;align-items: center;">
                <img class="img-logo" src="https://cdmadero.tecnm.mx/images/logo-itcm-v2.png" alt="ITCM">
                <!--Texto blacno y fw-bold float-end-->

                <nav class="sticker">
                    <ul class="menu">
                        <li><a class="header-container__a" href="RegistroUsuarios.php">Registrar</a>
                        </li>
                        <li><a class="header-container__a" href="../../Inicio.php">Inicio</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <main class="main">
        <div class="division">
            <div id="main" class="container-fluid pt-4">
                <div id="fmrlogin" class="container-fluid">
                    <div id="tramites_bienvenida" class="container  pt-5 pb-0  ">
                        <div id="fmrcols" class="" style="display: flex;justify-content: center;">
                            <div id="accesocol" class=""
                                style="padding: 15px 20px;width: 50%;border: 1px solid gray;border-radius: 10px;">

                                <form class=""  method="post">
                                    <p class="h4 font-weight-bold text-institucional text-center">Inicia Sesión</p>
                                    <hr class="bg-institucional">
                                    <p></p>

                                    <div class="container">
                                        <label for="correoElectronico"><b>Email</b></label>
                                        <input type="email" class="form-control" id="usuario" placeholder="CorreoEjemplo@gmail.com"
                                            name="correoElectronico" required>

                                        <label for="contraseña"><b>Contraseña</b></label>
                                        <input type="password" class="form-control" id="password"
                                            placeholder="contraseña" name="contraseña" required>
                                        <br>
                                        <button id="btn-login" type="sumbit"
                                            class="  col-12 text-white float-end division__button">Ingresar</button>

                                    </div>
                                    
                                    <div style="font-size:16px; color:#cc0000;">
                                    <?php echo $mensaje; ?>
                                    </div>
                                 

                                </form>
                            </div>
                        </div>
                    </div>
                    <div id="fmr_fmr" data-fmr="fmrlogin" data-func="fmrlogin.iniciar" data-cr="1111" data-nfmr="0">
                    </div>
                </div>
            </div>

        </div>
        </div>
    </main>

    <footer class="pie-pagina text-center" id="myFooter">
        <p>Powered By ISC ITCM © 2024.</p>
    </footer>
    <script src="../JS/controlFooter.js"></script>
</body>

</html>