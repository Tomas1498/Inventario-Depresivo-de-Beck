<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <title>Resultados Alumnos</title>
</head>

<body>
    <header>
        <div class="header-container">
            <div
                style="width: 100%;display: flex;flex-direction: row;flex-wrap: nowrap;justify-content: space-between;align-items: center;">
                <img class="img-logo" src="https://cdmadero.tecnm.mx/images/logo-itcm-v2.png" alt="ITCM">
                <!--Texto blacno y fw-bold float-end-->

                <nav class="sticker">
                    <ul class="menu">
                        <li><a class="header-container__a" href="RegistroUsuarios.php">Registrar</a>
                        </li>
                        <li><a class="header-container__a" href="../../Inicio.php">Inicio</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <main>
        <div class="division">
            <h1 class="division__h1">Tabla de Alumnos en monitoreo</h1>
            <div class="division__form">
                <p class="Info_center">En esta tabla se presentan los alumnos alumnos y sus resultados de seguimiento.Para poder acceder
                    a los resultados de cada formulario realizado por un alumno en especifico, dar click en el enlace "resultados" 
                    en la fila del alumno que desea monitorear.
                </p>
                <div>
                    <table border="1">
                    <?php include '../modulos/CargaDeResultados.php'; ?> 
                    </table>
                </div>
            </div>
        </div>
    </main>
    <footer class="pie-pagina text-center" id="myFooter">
        <p>Powered By ISC ITCM © 2024.</p>
    </footer>
</body>

</html>