<?php # Script 4.2 - registro.php
	$mensaje='';
	include ('../modulos/Registrar.php');
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <!--<link rel="stylesheet" href="../css/Registro.css"> este ya no es util.-->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css.map">
    <link rel="stylesheet" href="../css/bootstrap.rtl.min.css">
    <title>Registro</title>
</head>

<body>
    <header>
        <div class="header-container">
            <div
                style="width: 100%;display: flex;flex-direction: row;flex-wrap: nowrap;justify-content: space-between;align-items: center;">
                <img class="img-logo" src="https://cdmadero.tecnm.mx/images/logo-itcm-v2.png" alt="ITCM">
                <!--Texto blacno y fw-bold float-end-->

                <nav class="sticker">
                    <ul class="menu">
                        <li><a class="header-container__a" href="ResultadosAdmin.php">Resultados</a>
                        </li>
                        <li><a class="header-container__a" href="../../Inicio.php">Inicio</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <main>
        <div class="division">
            <div id="main" class="container-fluid pt-4">
                <div id="fmrRegistro" class="container-fluid">
                    <div id="tramites_registro" class="container  pt-5 pb-0  ">
                        <div id="fmrcols" class="" style="display: flex;justify-content: center;">
                            <div id="accesNewUser" style="padding: 15px 20px;width: 50%;border: 1px solid gray;border-radius: 10px;">

                                <form class="" action="" method="POST">
                                    <p class="h4 font-weight-bold text-institucional text-center">Registro Usuario</p>
                                    <hr class="bg-institucional">
                                    <p></p>

                                    <div class="container">
                                        <label for="registrousuario"><b>Usuario</b></label>
                                        <input type="text" class="form-control" id="NewUser"
                                            placeholder="Nombre completo" name="registrousuario" required>


                                        <label for="númeroControl"><b>Número de control</b></label>
                                        <input type="number" class="form-control" placeholder="18061824" name="númeroControl" id="NoControl"
                                            required>

                                        <label for="carreras"><b>Carrera</b></label>
                                        <select class="form-control" name="carreras" id="RegistroCarreras" required>
                                            <option value="Admon">------</option>
                                            <option value="Ingeniería en Sistemas">Ingeniería en Sistemas</option>
                                            <option value="Ingeniería Ambiental">Ingeniería Ambiental</option>
                                            <option value="Ingeniería Mecanica">Ingeniería Mecanica</option>
                                            <option value="Ingeniería Industrial">Ingeniería Industrial</option>
                                            <option value="Ingeniería Geociencias">Ingeniería Geociencias</option>
                                            <option value="Ingeniería Gestion Empresarial">Ingeniería Gestion Empresarial</option>
                                            <option value="Ingeniería Electrica">Ingeniería Electrica</option>
                                            <option value="Ingeniería Electronica">Ingeniería Electronica</option>
                                            <option value="Ingeniería Petrolera">Ingeniería Petrolera</option>
                                            <option value="Ingeniería Quimica">Ingeniería Quimica</option>
                                        </select>
                                        <label for="rol"><b>Rol del usuario</b></label>
                                        <select class="form-control" name="rol" id="RolUsuario" required>
                                            <option value="administrador">Administrador</option>
                                            <option value="alumno">Alumno</option>
                                           
                                        </select>
                                        
                                        <label for="correoElectronico"><b>Correo</b></label>
                                        <input type="email" class="form-control" id="CorreoRegistro"
                                            placeholder="L18@tcecmadero.mx" name="correoElectronico" required>

                                       
                                        <label for="contraseña"><b>Contraseña</b></label>
                                        <input type="password" class="form-control" id="psw" placeholder="********"
                                            name="contraseña" required>
                                            
                                    
                                        <br>
                                        <button id="btn-registrar" type="submit" value="registrar"
                                            class="  col-12 text-white float-end division__button">Registrar</button>

                                    </div>
                                    <div style="font-size:16px; color:#cc0000;">
                                    <?php echo $mensaje; ?>
                                    </div>


                                </form>
                               
                            </div>
                        </div>
                    </div>
                    <div id="fmr_fmr" data-fmr="fmrlogin" data-func="fmrSingup.registrar" data-cr="1111" data-nfmr="0">
                    </div>
                </div>
            </div>
          
        </div>
    </main>
    <footer class="pie-pagina text-center" id="myFooter">
        <p>Powered By ISC ITCM © 2024.</p>
    </footer>
    <script src="../JS/controlFooter.js"></script>
</body>

</html>