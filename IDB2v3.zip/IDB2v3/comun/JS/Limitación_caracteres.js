function soloLetrasYEspacios(event) {
    // Expresión regular que permite solo letras y espacios
    var regex = /^[a-zA-Z\s]*$/;

    // Obtener el valor del campo de entrada
    var input = event.target;
    var value = input.value;

    // Si el valor no cumple con la expresión regular, eliminar el último carácter ingresado
    if (!regex.test(value)) {
        input.value = value.slice(0, -1);
    }
}

function validarFormulario() {
    // Aquí puedes agregar más validaciones si es necesario
    return true; // Permitir el envío del formulario
}