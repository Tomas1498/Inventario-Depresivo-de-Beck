window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const mensaje = urlParams.get('mensaje');
    if (mensaje === 'exito') {
        alert('Respuestas guardadas exitosamente. Sus datos estan seguros y solo seran usados para el formulario. Cualquier duda comunicarse con el psicologo');
    } else if (mensaje === 'error') {
        alert('Hubo un error al guardar las respuestas. Por favor, inténtelo de nuevo.');
    }
}
