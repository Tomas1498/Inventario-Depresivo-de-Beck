function validarFormulario() {
    for (let i = 1; i <= 21; i++) {
        let respuestas = document.getElementsByName('respuesta' + i);
        console.log('Respuestas para pregunta ' + i + ':', respuestas);
        let preguntaRespondida = false;
        for (let respuesta of respuestas) {
            if (respuesta.checked) {
                preguntaRespondida = true;
                break;
            }
        }
        if (!preguntaRespondida) {
            alert('Por favor, responde todas las preguntas antes de enviar el formulario.');
            return false;
        }
    }
    return true;
}