-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 20-05-2024 a las 04:17:24
-- Versión del servidor: 10.5.20-MariaDB
-- Versión de PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id20885589_inventario_depresivo_berck`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_mentalusuarios`
--

CREATE TABLE `estado_mentalusuarios` (
  `Id_Resultado` int(11) NOT NULL,
  `Id_usuario` int(11) DEFAULT NULL,
  `Estado_Mental` varchar(50) DEFAULT NULL,
  `Fecha_Formulario` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id_formulario` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `pregunta01` int(11) DEFAULT NULL,
  `pregunta02` int(11) DEFAULT NULL,
  `pregunta03` int(11) DEFAULT NULL,
  `pregunta04` int(11) DEFAULT NULL,
  `pregunta05` int(11) DEFAULT NULL,
  `pregunta06` int(11) DEFAULT NULL,
  `pregunta07` int(11) DEFAULT NULL,
  `pregunta08` int(11) DEFAULT NULL,
  `pregunta09` int(11) DEFAULT NULL,
  `pregunta10` int(11) DEFAULT NULL,
  `pregunta11` int(11) DEFAULT NULL,
  `pregunta12` int(11) DEFAULT NULL,
  `pregunta13` int(11) DEFAULT NULL,
  `pregunta14` int(11) DEFAULT NULL,
  `pregunta15` int(11) DEFAULT NULL,
  `pregunta16` int(11) DEFAULT NULL,
  `pregunta17` int(11) DEFAULT NULL,
  `pregunta18` int(11) DEFAULT NULL,
  `pregunta19` int(11) DEFAULT NULL,
  `pregunta20` int(11) DEFAULT NULL,
  `pregunta21` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID` int(11) NOT NULL,
  `Nombre` varchar(255) NOT NULL,
  `No_Control` int(11) NOT NULL,
  `Carrera` varchar(100) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Contrasena` varchar(100) DEFAULT NULL,
  `rol` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID`, `Nombre`, `No_Control`, `Carrera`, `Email`, `Contrasena`, `rol`) VALUES
(1, 'Administrador', 0, 'vacio', 'L18Administrador@tecmadero.mx', 'yadira', 'administrador');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
