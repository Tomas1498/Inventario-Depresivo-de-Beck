<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ITCM Inventario berckII</title>
    <link rel="stylesheet" href="comun/css/StyleInicio.css">
    <script src="comun/JS/mensajeFormulario.js"> </script>
</head>

<body>

    <header>
        <div class="header-container">
            <!--Esta sección debe llevar el logo del tec al inicio izquierdo de la pagina-->
            <div style="width: 100%;display: flex;flex-direction: row;flex-wrap: nowrap;justify-content: space-between;align-items: center;">
                <img class="img-logo" src="https://cdmadero.tecnm.mx/images/logo-itcm-v2.png" alt="ITCM">
                <!--Texto blacno y fw-bold float-end-->

                <nav class="sticker">
                    <ul class="menu">
                        <!--Resultados y registros solo debe aparecer cuando inicie sesión el administrador-->
                        <?php
                        session_start();

                        // Verificar si el usuario ha iniciado sesión y es administrador
                        if (isset($_SESSION['email']) && isset($_SESSION['rol']) && $_SESSION['rol'] === 'administrador') {
                            echo '<li><a class="header-container__a" href="comun/PHP/ResultadosAdmin.php">Resultados</a></li>';
                            echo '<li><a class="header-container__a" href="comun/PHP/RegistroUsuarios.php">Registro</a></li>';
                        }
                        ?>

                        <?php
                        // Verificar si el usuario ha iniciado sesión
                        if (isset($_SESSION['email'])) {
                            // Si el usuario ha iniciado sesión, mostrar el enlace para cerrar sesión
                            echo '<li><a class="header-container__a" href="comun/modulos/CloseLog.php">Cerrar Sesión</a></li>';
                        } else {
                            // Si el usuario no ha iniciado sesión, mostrar el enlace para iniciar sesión
                            echo '<li><a class="header-container__a" href="comun/PHP/InicioSesión.php">Iniciar Sesión</a></li>';
                        }
                        ?>
                    </ul>
                </nav>
            </div>

        </div>
    </header>
    <main class="main">
        <div class=" main-container">
            <div class="division">
                <div class="division__form ">
                    <!--Idea presentar infromación,opcional poner el logo del tec de fondo como alguna de las paginas del tec-->
                    <div>
                        <h1 class="division__h1">Inventario depresivo de Berck II</h1>
                        <p class="Info_center">
                            El Instituto tecnologico de ciudad Madero se preocupa por la salud mental de sus
                            estiduantes.Para evaluar el estado de salud mental del alumno en busca de un posible
                            indicio de sintomas de ansiedad o sintomas depresivos, se proporciona la posibilidad
                            de realizar siguiente formulario.Presiona el siguiente boton para iniciar el formulario.
                            <b>Favor de iniciar sesión primero para poder redireccionarlo</b>.
                        </p>
                    </div>

                </div>
                <div>
                
                        <?php
                        //si el usuario no a iniciado sesión no puede proceder al test
                        if (isset($_SESSION['email'])) {
                           
                            echo '<form> <a href="comun/PHP/Inventario depresivo de berk.php"><input class="division__button" type="button" value="Inventario depresivo de berk"></a></form>';
                            }
                        ?>
                        
                    
                </div>
            </div>
            
        </div>
    </main>

    <footer class="pie-pagina text-center" id="myFooter">
        <p>Powered By ISC ITCM © 2024.</p>
    </footer>
    

</body>

</html>